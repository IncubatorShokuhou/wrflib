This directory hierarchy contains the source code for JasPer.
