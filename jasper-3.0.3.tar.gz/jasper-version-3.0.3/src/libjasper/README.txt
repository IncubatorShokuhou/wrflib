This directory hierarchy contains the source code for the JasPer library
(i.e., libjasper).
