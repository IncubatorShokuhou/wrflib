This directory contains numerous image files whose contents correspond
to valid image data, although in some cases the image data may be bizarre
(e.g., an image with zero components).
