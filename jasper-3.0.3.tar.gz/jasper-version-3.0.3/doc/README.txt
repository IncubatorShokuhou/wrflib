This directory contains documentation related to the JasPer software.

jpeg2000.pdf
    A detailed technical tutorial on the JPEG-2000 standard.
